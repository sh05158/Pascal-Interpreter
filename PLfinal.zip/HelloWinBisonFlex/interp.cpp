#include "AST.h"
#include "interp.h"
#include <setjmp.h>
#include <iostream>

using namespace std;


int envp = 0;
Environment Env[MAX_ENV];

jmp_buf *funcReturnEnv;
int funcReturnVal;

static int executeFuncArgs(AST *params,AST *args);

void defineFunction(Symbol *fsym,AST *params,AST *body)
{
    fsym->func_params = params;
    fsym->func_body = body;
}

/*
 * For environment
 */
int setValue(Symbol *var,int val)
{
    int i;
    for(i = envp-1; i >= 0; i--){
	if(Env[i].var == var){
	    Env[i].val = val;
	    return val;
	}
    }
    var->val = val;
    return val;
}

int getValue(Symbol *var)
{
    int i;
    for(i = envp-1; i >= 0; i--){
	if(Env[i].var == var) return Env[i].val;
    }
    return var->val;
}

float getArray(Symbol *var, int index)
{
	//cout << "ASDF" << endl;
	if (index < 0 || index >= var->size) {
		error(string(var->name)+ " Out of Index Error");
	}
	int i;
	for (i = envp - 1; i >= 0; i--) {
		if (Env[i].var == var) {
			//cout << "" << endl;
			return Env[i].arrAddr[index];
		}
	}
	return var->val;
}

float setArray(Symbol *var, int index, float value)
{
	if (index < 0 || index >= var->size) {
		error(string(var->name) + " Out of Index Error");
	}
	//cout << "NAME: "<<var->name << endl;
	int i;
	for (i = envp - 1; i >= 0; i--) {
		if (Env[i].var == var) {
			//cout << "ã�Ҵ�" << endl;
			Env[i].arrAddr[index] = value;
			//cout << "�� ����" << endl;
			return Env[i].arrAddr[index];
		}
	}
	return var->val;
}




int executeCallFunc(Symbol *f,AST *args)
{
	//cout << "ã�Ƽ� ������" << endl;
    int nargs;
    int val;
    jmp_buf ret_env;
    jmp_buf *ret_env_save;
    
    nargs = executeFuncArgs(f->func_params,args);

    ret_env_save = funcReturnEnv;
    funcReturnEnv = &ret_env;

    if(setjmp(ret_env) != 0){
	val = funcReturnVal;
    } else {
		//cout << "�Լ��� body�� �����մϴ�" << endl;
	executeStatement(f->func_body);

    }
    envp -= nargs;
    funcReturnEnv = ret_env_save;
    return val;
}

static int executeFuncArgs(AST *params,AST *args)
{
	/*if ((args == NULL && params != NULL) || (args != NULL && params == NULL)) {
		cout << "ERROR" << endl;
		exit(1);
	}*/
	if (params == NULL) {
		cout << "�Լ��� �Ķ���Ͱ� ����" << endl;
		return 0;
	}
	/*if (getFirst(params)->sym->type == I && (getFirst(args)->op == NUM || getFirst(args)->sym->type == I));
	else{
		cout << "�Լ� ���ڰ� INT��" << endl;
		exit(1);
	}*/
	Symbol *var;
	int val;

	int nargs;

	val = executeExpr(getFirst(args));
	var = getSymbol(getFirst(params));
	nargs = executeFuncArgs(getNext(params),getNext(args));

  
  /*if (getFirst(args)->op == NUM || getFirst(args)->op == FLO) {
	  Env[envp].var = var;
	  Env[envp].val = val;
	  if (getFirst(args)->op == NUM) {	
		  Env[envp].type = I;
	  }
	  else {
		  Env[envp].type = F;
	  }
	
  }
  else if (getFirst(args)->sym->type == I || getFirst(args)->sym->type == F) {
	  Env[envp].var = var;
	  Env[envp].val = val;
	  Env[envp].type = getFirst(params)->sym->type;
  }*/

	if (!isOp(getFirst(args))) { //���ڰ� ������ �Ǽ��� �ƴ� ���
		if (isArray(getFirst(args))) {
			cout << "�迭 ���� �Ѱܹ���" << endl;

			Symbol * temp =getSymbol(getFirst(args));
			for (int i = envp; i > -1; i--) {
				if (Env[i].var == temp) {
					Env[envp].var = getSymbol(getFirst(params));
					Env[envp].arrAddr = Env[i].arrAddr;
					Env[envp].var->size = Env[i].var->size;
					break;
				}
			}

			/*Env[envp].var = var;
			Env[envp].arrAddr = (float*)malloc(sizeof(float)*getFirst(args)->sym->size);
			Env[envp].type = getFirst(args)->sym->type;
			Env[envp].var->size = getFirst(args)->sym->size;

			for (int i = 0; i < Env[envp].var->size; i++) {
				//Env[envp].arrAddr[i] = getFirst(args)->sym->addr[i];
				Env[envp].arrAddr[i] = lookupSymbol(getFirst(args)->sym->name)->addr[i];
			}
			*/
			cout << Env[envp].var->size << endl;
		}
		else {
			cout << "���� ����" << endl;
			Env[envp].var = var;
			Env[envp].val = val;
		}
	}
	else {
		//���ڰ� ������ �Ǽ��� ���.
		Env[envp].var = var;
		Env[envp].val = val;
	}
	
  
  envp++;
  
  return nargs+1;
}

bool isArray(AST* p) {
	if (p->sym == NULL)	return false;
	if (p->sym->type == I)	return false;
	if (p->sym->type == F)	return false;
	if (p->sym->type == IA || p->sym->type == FA)	return true;
	return false;
}

bool isOp(AST* p) {
	if (p->op == EQ_OP)	return true;
	if (p->op == PLUS_OP)	return true;
	if (p->op == MINUS_OP)	return true;
	if (p->op == MUL_OP)	return true;
	if (p->op == LT_OP)	return true;
	if (p->op == GT_OP)	return true;
	if (p->op == LOE_OP)	return true;
	if (p->op == GOE_OP)	return true;
	if (p->op == DIV_OP)	return true;
	if (p->op == DIFF_OP)	return true;

	if (p->op == EQUAL_OP)	return true;
	if (p->op == NOT_OP)	return true;
	return false;
}

void executeReturn(AST *expr)
{
    funcReturnVal = executeExpr(expr);
    longjmp(*funcReturnEnv,1);
}

void executeStatement(AST *p)
{
    if(p == NULL) return;
    switch(p->op){
    case BLOCK_STATEMENT:
	//cout << "BLOCK_STATEMENT" << endl;
	executeBlock(p->left,p->right);
	break;
    case RETURN_STATEMENT:
	executeReturn(p->left);
	break;
    case IF_STATEMENT:
	executeIf(p->left,getNth(p->right,0),getNth(p->right,1));
	break;
    case WHILE_STATEMENT:
		//cout << "��"<<p->left->left->sym->name << endl;
		executeWhile(p->left, p->right);
	break;
    default:
		//cout << "defaultstatement" << endl;
	executeExpr(p);
    }
}

void executeBlock(AST *local_vars,AST *statements)
{
    AST *vars;
    int envp_save;

    envp_save = envp;
	for (vars = local_vars; vars != NULL; vars = getNext(vars)) {
		Symbol *temp = getSymbol(getFirst(vars));
		//cout << "���ú��� ������" << endl;
		if (temp->type == I || temp->type == F) {
			Env[envp].var = temp;
		}
		else if (temp->type == IA || temp->type == FA) {
			Env[envp].var = temp;
			
			Env[envp].arrAddr = (float*)malloc(temp->size * sizeof(float));
			for (int i = 0; i < temp->size; i++) {
				Env[envp].arrAddr[i] = 0;
			}

		}
		else {
			//cout << "type error" << endl;
			exit(1);
		}
		Env[envp++].type = temp->type;
	}
	for (; statements != NULL; statements = getNext(statements)) {
		//cout << "statement ������" << endl;
		//cout << statements << endl;
		executeStatement(getFirst(statements));
	}
    envp = envp_save;
    return;
}

void executeIf(AST *cond, AST *then_part, AST *else_part)
{
	//cout << "cond:" << cond->right->sym->val << endl;
	if (executeExpr(cond))
		executeBlock(NULL, then_part);
	//executeStatement(then_part);
	else
		executeBlock(NULL, else_part);
	//executeStatement(else_part);
}

void executeWhile(AST *cond,AST *body)
{
	while (executeExpr(cond)) {
		//cout<<cond->left->sym->name<<endl;
		//executeStatement(body);
		executeBlock(NULL, body);
	}
}

void executeFor(AST *init,AST *cond,AST *iter,AST *body)
{
    /* not implmented */
}




void error(string msg) {
	cout << msg << endl;
	exit(1);
}